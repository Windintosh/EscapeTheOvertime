// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.Collections.Generic;

public class EscapeTheOvertimeTarget : TargetRules
{
	public EscapeTheOvertimeTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_5; // 버전은 5.4, 5.5 등 사용중인 엔진 버전에 맞게
		ExtraModuleNames.Add("EscapeTheOvertime");
	}
}
