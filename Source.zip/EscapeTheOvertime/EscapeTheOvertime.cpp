// Copyright Epic Games, Inc. All Rights Reserved.

#include "EscapeTheOvertime.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, EscapeTheOvertime, "EscapeTheOvertime" );

DEFINE_LOG_CATEGORY(LogEscapeTheOvertime)