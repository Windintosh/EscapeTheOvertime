// Copyright Epic Games, Inc. All Rights Reserved.

#include "EscapeTheOvertimeGameMode.h"

AEscapeTheOvertimeGameMode::AEscapeTheOvertimeGameMode()
{
	// stub
}
